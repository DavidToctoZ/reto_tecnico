let config = {
    
    tabla_dynamo:"personas_prueba"
}




module.exports = {config};